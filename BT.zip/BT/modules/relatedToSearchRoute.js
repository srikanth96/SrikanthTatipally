function resetFrmSearchRoute(){
  	frmSearchByRoute.txtCurrentLocation.text = "";
  	frmSearchByRoute.txtGoToLocation.text = "";
  	frmSearchByRoute.segBusNosList.isVisible = false;
}

function onClickOfSearchBtnInfrmSearchRoutes(validated){
  	var from = frmSearchByRoute.txtCurrentLocation.text;
  	var to	= frmSearchByRoute.txtGoToLocation.text;
  
  	if(!validated){
    	if(isNullable(from) || isNullable(to)){
       		alert("Enter Proper Value");
          	return;
    	}
    }
  	frmSearchByRoute.segBusNosList.isVisible = true;
}
