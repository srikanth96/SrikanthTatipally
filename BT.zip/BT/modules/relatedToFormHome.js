function preShowMethodofFrmHome(){
  	
  	var from = frmHome.txtCurrentLocation.text;
  	var to	= frmHome.txtGoToLocation.text;
  
  	frmHome.segBusTracking.isVisible = false;
  	if(!(isNullable(from) || isNullable(to))){
       onClickOfSearchBtnInfrmHome(true);
    }
}

function onClickOfSearchBtnInfrmHome(validated){
  	
  	var from = frmHome.txtCurrentLocation.text;
  	var to	= frmHome.txtGoToLocation.text;
  
  	if(!validated){
    	if(isNullable(from) || isNullable(to)){
       		alert("Enter Proper Value");
          	return;
    	}
    }
  	frmHome.segBusTracking.isVisible = true;
}

function onClickOfGPSForCurrentLocation(){
  	kony.application.getCurrentForm().txtCurrentLocation.text = onClickOfRefreshBtn();
}

function onClickOfSearchRoutesInFrmHome(){
  	
  	in_MoveInRtoL(frmSearchByRoute);
	frmSearchByRoute.show();
  
  	resetFrmSearchRoute();
  	var from = frmSearchByRoute.txtCurrentLocation.text = frmHome.txtCurrentLocation.text;
  	var to = frmSearchByRoute.txtGoToLocation.text = frmHome.txtGoToLocation.text;
  
  	if(!(isNullable(from) || isNullable(to))){
       onClickOfSearchBtnInfrmSearchRoutes(true);
    }
}

function onClickOfStopsNearMe(){
  	in_MoveInRtoL(frmStopsNearMe);
	frmStopsNearMe.show();
  	
  	resetFrmStopsNearMe();
}

function onRowClickOfSegBusTracking(){
  	in_MoveInRtoL(frmBusInfo);
  	frmBusInfo.show();
  	
  	populateBusInfo("250S");
}