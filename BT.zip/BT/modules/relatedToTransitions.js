/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function in_MoveInRtoL(formName) {
	formName.inTransitionConfig = {
		transitionEffect: "transitionMoveIn",
		transitionDirection: "fromRight"
	};
}

/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function out_MoveInRtoL(formName) {
	formName.outTransitionConfig = {
		transitionEffect: "transitionMoveIn",
		transitionDirection: "fromRight"
	};
}

/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function out_RevealTtoB(formName) {
	formName.outTransitionConfig = {
		transitionEffect: "transitionReveal",
		transitionDirection: "fromTop"
	};
}

/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function out_RevealLtoR(formName) {
	formName.outTransitionConfig = {
		transitionEffect: "transitionReveal",
		transitionDirection: "fromLeft"
	};
}

/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function out_MoveIn(formName) {
	formName.outTransitionConfig = {
		transitionEffect: "transitionMoveIn"
	};
}

/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function in_fade(formName) {
	formName.inTransitionConfig = {
		transitionEffect: "transitionFade"
	};
}

/**
* @param  {JSON} - formName - holds the formReference
* @return {void} - none.
* @description 	 - assigning the transition for a form
*/
function out_fade(formName) {
	formName.outTransitionConfig = {
		transitionEffect: "transitionFade"
	};
}