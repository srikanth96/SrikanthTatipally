function populateBusInfo(busNo){
  	var data = searchStopsOfBusNo(busNo);
  
  	populateBusRoutes(data);
}

function searchStopsOfBusNo(busNo){
  	var dataOfStops = [];
  	var len = gBusRouteList.length;
  
  	for(var i =0; i < len; i++){
      	if(gBusRouteList[i].bus_service_no === busNo){
          	dataOfStops.push(gBusRouteList[i]);
        }
    }
  	
  	dataOfStops.sort(function(a,b){
      	var x = a.order;
		var y = b.order;
		return parseInt(x) - parseInt(y);
    });
  	return dataOfStops;
}

function populateBusRoutes(data){
  	var len = data.length;
  	frmBusInfo.flxScrollBus.removeAll();
  	for(var i = 0; i< len ;i++){
      	var lbl = dynamicLabel(i);
      	lbl.text = gAllBusStopsList[parseInt(data[i].bus_stop_id) - 1].bus_stop_long;
      	frmBusInfo.flxScrollBus.add(lbl);
      	if(i < len - 1){
          	var img = dynamicImage(i);
          	frmBusInfo.flxScrollBus.add(img);
        }
    }
}

function dynamicLabel(i){
  	var lbl = new kony.ui.Label({
			"id" : "lblBusStop_" + i,
			"centerX" : "50%",
			"top" : "3%",
      		"width":"80%",
			"skin" : "sknLbl5E5050News93",
			"text" : "text",
			"zIndex" : 1,
			isVisible : true
		}, {
			"widgetAlignment" : constants.WIDGET_ALIGN_CENTER,
			"vExpand" : false,
			"hExpand" : false,
			"contentAlignment" : constants.CONTENT_ALIGN_CENTER,
			"marginInPixel" : false,
			"paddingInPixel" : false,
			"containerWeight" : 85
		}, {});
  return lbl;
}

function dynamicImage(i){
  	var img = new kony.ui.Image2({
			"id" : "imgDownArrow_" + i,
			"centerX" : "50%",
			"top" : "3%",
			"width" : "18dp%",
			"height" : "18dp",
			"isVisible" : true,
			"src" : "down_arrow.png"
		}, {}, {});
  
  	return img;
}