function onRowClickOfSegment(){
  	out_RevealLtoR(frmFavourites);
  	frmHome.show();
  
  	var data = frmFavourites.segBusStops.selectedItems[0];
  	
  	frmHome.txtCurrentLocation.text = data.lblFrom ;
  	frmHome.txtGoToLocation.text = data.lblTo;
  
  	onClickOfSearchBtnInfrmHome(false);
}
