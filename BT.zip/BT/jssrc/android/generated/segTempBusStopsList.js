function initializesegTempBusStopsList() {
    flxSegTempBusStopsList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "60dp",
        "id": "flxSegTempBusStopsList",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxSegTempBusStopsList.setDefaultUnit(kony.flex.DP);
    var lblStatusValue = new kony.ui.Label({
        "centerY": "50%",
        "height": "80%",
        "id": "lblStatusValue",
        "isVisible": true,
        "left": "7%",
        "skin": "sknLbl5E5050News93",
        "text": "FULL",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10%",
        "width": "86%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblLine = new kony.ui.Label({
        "bottom": "0%",
        "height": "1dp",
        "id": "lblLine",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblD8D8D8BGop50",
        "text": ":",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxSegTempBusStopsList.add(
    lblStatusValue, lblLine);
}