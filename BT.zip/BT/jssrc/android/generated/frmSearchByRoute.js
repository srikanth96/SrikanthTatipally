function addWidgetsfrmSearchByRoute() {
    frmSearchByRoute.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var imgHeaderBack = new kony.ui.Image2({
        "centerY": "50%",
        "height": "24dp",
        "id": "imgHeaderBack",
        "isVisible": true,
        "left": "5%",
        "skin": "slImage",
        "src": "back_btnn_white.png",
        "top": "12%",
        "width": "19dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblHeaderTitle = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblHeaderTitle",
        "isVisible": true,
        "left": "12%",
        "skin": "sknLblFFFFFFNews36",
        "text": "Search Routes",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "12dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnBack = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopyslButtonGlossBlue010ff396f1e184b",
        "height": "50dp",
        "id": "btnBack",
        "isVisible": true,
        "left": 2,
        "onClick": AS_Button_64db71d0acf0499f95d91d08397ba00f,
        "right": "5%",
        "skin": "CopyslButtonGlossBlue010ff396f1e184b",
        "text": "Button",
        "top": "83%",
        "width": "50dp",
        "zIndex": 3
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxHeader.add(
    imgHeaderBack, lblHeaderTitle, btnBack);
    var flxInputArea = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": false,
        "height": "22%",
        "id": "flxInputArea",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknFlx000000BGop20rad15",
        "top": "8%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxInputArea.setDefaultUnit(kony.flex.DP);
    var lblFrom = new kony.ui.Label({
        "height": "13%",
        "id": "lblFrom",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblFFFFFFBook28",
        "text": "From",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var txtCurrentLocation = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "sknTbx000000BGop15RCFFFFFFNews100",
        "height": "24%",
        "id": "txtCurrentLocation",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "0%",
        "placeholder": "My Current Location",
        "secureTextEntry": false,
        "skin": "sknTbx000000BGop15RCFFFFFFNews100",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "20%",
        "width": "89%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "placeholderSkin": "sknTbx000000BGop15RCFFFFFFBook100",
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var flxGPS = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40dp",
        "id": "flxGPS",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "90%",
        "skin": "slFbox",
        "top": "20%",
        "width": "40dp"
    }, {}, {});
    flxGPS.setDefaultUnit(kony.flex.DP);
    var lblGPS = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "45%",
        "height": "25dp",
        "id": "lblGPS",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "gps.png",
        "top": "0dp",
        "width": "25dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxGPS.add(
    lblGPS);
    var lblTo = new kony.ui.Label({
        "height": "13%",
        "id": "lblTo",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblFFFFFFBook28",
        "text": "To",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "49%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var txtGoToLocation = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "sknTbx000000BGop15RCFFFFFFNews100",
        "height": "24%",
        "id": "txtGoToLocation",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "0%",
        "placeholder": "Go To Location",
        "secureTextEntry": false,
        "skin": "sknTbx000000BGop15RCFFFFFFNews100",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "64%",
        "width": "89%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "placeholderSkin": "sknTbx000000BGop15RCFFFFFFBook100",
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var flxSearchBuses = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40dp",
        "id": "flxSearchBuses",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "90%",
        "skin": "slFbox",
        "top": "64%",
        "width": "40dp"
    }, {}, {});
    flxSearchBuses.setDefaultUnit(kony.flex.DP);
    var imgSearchBuses = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "45%",
        "height": "25dp",
        "id": "imgSearchBuses",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "search.png",
        "top": "0dp",
        "width": "25dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSearchBuses.add(
    imgSearchBuses);
    flxInputArea.add(
    lblFrom, txtCurrentLocation, flxGPS, lblTo, txtGoToLocation, flxSearchBuses);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "70%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0c662c5a242d84b",
        "top": "30%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var segBusNosList = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "btnFav": "Button",
            "imgFav": "star_unselected.png",
            "lblLine": ":",
            "lblStatusValue": "10H"
        }, {
            "btnFav": "Button",
            "imgFav": "star_selected.png",
            "lblLine": ":",
            "lblStatusValue": "147"
        }, {
            "btnFav": "Button",
            "imgFav": "star_unselected.png",
            "lblLine": ":",
            "lblStatusValue": "47V"
        }, {
            "btnFav": "Button",
            "imgFav": "star_unselected.png",
            "lblLine": ":",
            "lblStatusValue": "47V/17HN"
        }, {
            "btnFav": "Button",
            "imgFav": "star_selected.png",
            "lblLine": ":",
            "lblStatusValue": "10W/250"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segBusNosList",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxTempBusNosList,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": false,
        "showScrollbars": false,
        "top": "0%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "btnFav": "btnFav",
            "flxTempBusNosList": "flxTempBusNosList",
            "imgFav": "imgFav",
            "lblLine": "lblLine",
            "lblStatusValue": "lblStatusValue"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "dockSectionHeaders": true
    });
    flxBody.add(
    segBusNosList);
    flxOuter.add(
    flxHeader, flxInputArea, flxBody);
    frmSearchByRoute.add(
    flxOuter);
};

function frmSearchByRouteGlobals() {
    frmSearchByRoute = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmSearchByRoute,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "frmSearchByRoute",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "sknFrmStandardGradient"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};