function initializesegTempBusNosList() {
    flxTempBusNosList = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "13%",
        "id": "flxTempBusNosList",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxTempBusNosList.setDefaultUnit(kony.flex.DP);
    var lblStatusValue = new kony.ui.Label({
        "centerY": "50%",
        "height": "50%",
        "id": "lblStatusValue",
        "isVisible": true,
        "left": "7%",
        "skin": "sknLbl5E5050News93",
        "text": "FULL",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10%",
        "width": "70%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblLine = new kony.ui.Label({
        "bottom": "0%",
        "height": "1dp",
        "id": "lblLine",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblD8D8D8BGop50",
        "text": ":",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var imgFav = new kony.ui.Image2({
        "centerY": "50%",
        "height": "30dp",
        "id": "imgFav",
        "isVisible": true,
        "right": "7%",
        "skin": "slImage",
        "src": "option1.png",
        "top": "83dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnFav = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopyslButtonGlossBlue010ff396f1e184b",
        "height": "50dp",
        "id": "btnFav",
        "isVisible": true,
        "right": "4%",
        "skin": "CopyslButtonGlossBlue010ff396f1e184b",
        "text": "Button",
        "top": "83%",
        "width": "50dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxTempBusNosList.add(
    lblStatusValue, lblLine, imgFav, btnFav);
}