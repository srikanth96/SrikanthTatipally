//actions.js file 
function AS_Button_64db71d0acf0499f95d91d08397ba00f(eventobject) {
    out_RevealLtoR(frmSearchByRoute);
    frmHome.show();
}
function AS_Button_8eb3b28252f846d9b01832486ed569bf(eventobject) {
    var prevForm = kony.application.getPreviousForm();
    out_RevealLtoR(frmMapView);
    prevForm.show();
}
function AS_Button_98edf64253c44ebf9d38e6ae1b6a3315(eventobject) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_Button_99133e1197e3483a9f74343624feffd7(eventobject, context) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_Button_f84543b328a24821ac0b43419407ed30(eventobject) {
    out_RevealLtoR(frmStopsNearMe);
    frmHome.show();
}
function AS_FlexContainer_c2a6b2af56f646f68ed2d590c11d2974(eventobject) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_FlexContainer_e67978d74a3541c1a592f5e6d25f41be(eventobject) {
    in_MoveInRtoL(frmStopsNearMe);
    frmStopsNearMe.show();
}
function AS_FlexContainer_eb7ef403a1b34d3bb7611e72e24dc7ef(eventobject) {
    in_MoveInRtoL(frmSearchByRoute);
    frmSearchByRoute.show();
}
function AS_Segment_43a852ca866543ad89af6284d4cc3fe0(eventobject, sectionNumber, rowNumber) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}