function addWidgetsfrmStopsNearMe() {
    frmStopsNearMe.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var imgHeaderBack = new kony.ui.Image2({
        "centerY": "50%",
        "height": "24dp",
        "id": "imgHeaderBack",
        "isVisible": true,
        "left": "5%",
        "skin": "slImage",
        "src": "back_btnn_white.png",
        "top": "12%",
        "width": "19dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblHeaderTitle = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblHeaderTitle",
        "isVisible": true,
        "left": "12%",
        "skin": "sknLblFFFFFFNews36",
        "text": "Stops Near me",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "12dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnBack = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopyslButtonGlossBlue010ff396f1e184b",
        "height": "50dp",
        "id": "btnBack",
        "isVisible": true,
        "left": 2,
        "onClick": AS_Button_f84543b328a24821ac0b43419407ed30,
        "right": "5%",
        "skin": "CopyslButtonGlossBlue010ff396f1e184b",
        "text": "Button",
        "top": "83%",
        "width": "50dp",
        "zIndex": 3
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxHeader.add(
    imgHeaderBack, lblHeaderTitle, btnBack);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "91%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0c662c5a242d84b",
        "top": "9%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var btnRefresh = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "CopyslButtonGlossBlue0eef05172dc8242",
        "height": "8.50%",
        "id": "btnRefresh",
        "isVisible": true,
        "left": "63dp",
        "skin": "CopyslButtonGlossBlue09763866fdaab46",
        "text": "Refresh",
        "top": "3%",
        "width": "60%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnViewOnMap = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "CopyslButtonGlossBlue0eef05172dc8242",
        "height": "8.50%",
        "id": "btnViewOnMap",
        "isVisible": true,
        "left": "63dp",
        "onClick": AS_Button_98edf64253c44ebf9d38e6ae1b6a3315,
        "skin": "CopyslButtonGlossBlue09763866fdaab46",
        "text": "View On Map",
        "top": "14.50%",
        "width": "60%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var segBusStops = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblLine": ":",
            "lblStatusValue": "Cyber Gateway"
        }, {
            "lblLine": ":",
            "lblStatusValue": "Cyber Towers"
        }],
        "groupCells": false,
        "height": "66%",
        "id": "segBusStops",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_43a852ca866543ad89af6284d4cc3fe0,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxSegTempBusStopsList,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": false,
        "showScrollbars": false,
        "top": "34%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxSegTempBusStopsList": "flxSegTempBusStopsList",
            "lblLine": "lblLine",
            "lblStatusValue": "lblStatusValue"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "dockSectionHeaders": true
    });
    var lblStatusValue = new kony.ui.Label({
        "height": "40dp",
        "id": "lblStatusValue",
        "isVisible": true,
        "left": "7%",
        "skin": "sknLbl5E5050News93",
        "text": "Stops are fethed based on your GPS Location.",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "26%",
        "width": "86%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxBody.add(
    btnRefresh, btnViewOnMap, segBusStops, lblStatusValue);
    flxOuter.add(
    flxHeader, flxBody);
    frmStopsNearMe.add(
    flxOuter);
};

function frmStopsNearMeGlobals() {
    frmStopsNearMe = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmStopsNearMe,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "frmStopsNearMe",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "sknFrmStandardGradient"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};