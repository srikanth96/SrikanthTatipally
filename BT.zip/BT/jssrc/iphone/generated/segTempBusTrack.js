function initializesegTempBusTrack() {
    flxTempBusTrack = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40%",
        "id": "flxTempBusTrack",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxTempBusTrack.setDefaultUnit(kony.flex.DP);
    var lblBusNo = new kony.ui.Label({
        "height": "12%",
        "id": "lblBusNo",
        "isVisible": true,
        "left": "4%",
        "skin": "sknLbl5E5050Book93",
        "text": "Bus No.",
        "top": "10%",
        "width": "20%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblColon1 = new kony.ui.Label({
        "height": "12%",
        "id": "lblColon1",
        "isVisible": true,
        "left": "24%",
        "skin": "sknLbl5E5050Book93",
        "text": ":",
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblBusNoValue = new kony.ui.Label({
        "height": "12%",
        "id": "lblBusNoValue",
        "isVisible": true,
        "left": "26%",
        "skin": "sknLbl1C3F65News100",
        "text": "10H",
        "top": "10%",
        "width": "25%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblStatus = new kony.ui.Label({
        "height": "12%",
        "id": "lblStatus",
        "isVisible": true,
        "left": "55%",
        "skin": "sknLbl5E5050Book93",
        "text": "Status",
        "top": "10%",
        "width": "15%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblColon2 = new kony.ui.Label({
        "height": "12%",
        "id": "lblColon2",
        "isVisible": true,
        "left": "68%",
        "skin": "sknLbl5E5050Book93",
        "text": ":",
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblStatusValue = new kony.ui.Label({
        "height": "12%",
        "id": "lblStatusValue",
        "isVisible": true,
        "left": "70%",
        "skin": "sknLbl5E5050News93",
        "text": "FULL",
        "top": "10%",
        "width": "25%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblBusType = new kony.ui.Label({
        "height": "12%",
        "id": "lblBusType",
        "isVisible": true,
        "left": "4%",
        "skin": "sknLbl5E5050Book93",
        "text": "Bus Type",
        "top": "26%",
        "width": "20%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblColon3 = new kony.ui.Label({
        "height": "12%",
        "id": "lblColon3",
        "isVisible": true,
        "left": "24%",
        "skin": "sknLbl5E5050Book93",
        "text": ":",
        "top": "26%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblBusTypeValue = new kony.ui.Label({
        "height": "12%",
        "id": "lblBusTypeValue",
        "isVisible": true,
        "left": "26%",
        "skin": "sknLbl5E5050News93",
        "text": "Metro",
        "top": "26%",
        "width": "50%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDistance = new kony.ui.Label({
        "height": "12%",
        "id": "lblDistance",
        "isVisible": true,
        "left": "4%",
        "skin": "sknLbl5E5050Book93",
        "text": "Distance",
        "top": "42%",
        "width": "20%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblColon4 = new kony.ui.Label({
        "height": "12%",
        "id": "lblColon4",
        "isVisible": true,
        "left": "24%",
        "skin": "sknLbl5E5050Book93",
        "text": ":",
        "top": "42%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDistanceValue = new kony.ui.Label({
        "height": "12%",
        "id": "lblDistanceValue",
        "isVisible": true,
        "left": "26%",
        "skin": "sknLbl5E5050News93",
        "text": "2 Kms",
        "top": "42%",
        "width": "35%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTime = new kony.ui.Label({
        "height": "12%",
        "id": "lblTime",
        "isVisible": true,
        "left": "4%",
        "skin": "sknLbl5E5050Book93",
        "text": "Estimated Time",
        "top": "58%",
        "width": "31%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblColon5 = new kony.ui.Label({
        "height": "12%",
        "id": "lblColon5",
        "isVisible": true,
        "left": "36%",
        "skin": "sknLbl5E5050Book93",
        "text": ":",
        "top": "58%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTimeValue = new kony.ui.Label({
        "height": "12%",
        "id": "lblTimeValue",
        "isVisible": true,
        "left": "38%",
        "skin": "sknLbl5E5050News93",
        "text": "8 Min",
        "top": "58%",
        "width": "35%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblBusLocation = new kony.ui.Label({
        "height": "12%",
        "id": "lblBusLocation",
        "isVisible": true,
        "left": "4%",
        "skin": "sknLbl5E5050Book93",
        "text": "Current Location",
        "top": "75%",
        "width": "40%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblColon6 = new kony.ui.Label({
        "height": "12%",
        "id": "lblColon6",
        "isVisible": true,
        "left": "36%",
        "skin": "sknLbl5E5050Book93",
        "text": ":",
        "top": "75%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblBusLocationValue = new kony.ui.Label({
        "height": "16%",
        "id": "lblBusLocationValue",
        "isVisible": true,
        "left": "38%",
        "skin": "sknLbl1C3F65News100",
        "text": "Kondapur Kondapur Konadapur",
        "top": "75%",
        "width": "49%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblLine = new kony.ui.Label({
        "bottom": "0%",
        "height": "1dp",
        "id": "lblLine",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblD8D8D8BGop50",
        "text": ":",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var imgBusMap = new kony.ui.Image2({
        "centerY": "50%",
        "height": "50dp",
        "id": "imgBusMap",
        "isVisible": true,
        "right": "7%",
        "skin": "slImage",
        "src": "show_map_view.png",
        "top": "83dp",
        "width": "35dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnBusMap = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopyslButtonGlossBlue010ff396f1e184b",
        "height": "50dp",
        "id": "btnBusMap",
        "isVisible": true,
        "onClick": AS_Button_99133e1197e3483a9f74343624feffd7,
        "right": "5%",
        "skin": "CopyslButtonGlossBlue010ff396f1e184b",
        "text": "Button",
        "top": "83%",
        "width": "50dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    flxTempBusTrack.add(
    lblBusNo, lblColon1, lblBusNoValue, lblStatus, lblColon2, lblStatusValue, lblBusType, lblColon3, lblBusTypeValue, lblDistance, lblColon4, lblDistanceValue, lblTime, lblColon5, lblTimeValue, lblBusLocation, lblColon6, lblBusLocationValue, lblLine, imgBusMap, btnBusMap);
}