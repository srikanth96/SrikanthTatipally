//actions.js file 
function AS_Button_64db71d0acf0499f95d91d08397ba00f(eventobject) {
    out_RevealLtoR(frmSearchByRoute);
    frmHome.show();
}
function AS_Button_8eb3b28252f846d9b01832486ed569bf(eventobject) {
    var prevForm = kony.application.getPreviousForm();
    out_RevealLtoR(frmMapView);
    prevForm.show();
}
function AS_Button_9057ff3cfeed471ead3e9cefa66b363d(eventobject) {
    onClickOfRefreshBtn();
}
function AS_Button_98edf64253c44ebf9d38e6ae1b6a3315(eventobject) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_Button_99133e1197e3483a9f74343624feffd7(eventobject, context) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_Button_b3d2d4ed84144957b320faf2f2bcaa6a(eventobject) {
    var prevForm = kony.application.getPreviousForm();
    out_RevealLtoR(frmBusInfo);
    prevForm.show();
}
function AS_Button_bf5027e9a4d84ee08bcc69bc99cb7e5e(eventobject) {
    out_RevealLtoR(frmFavourites);
    frmHome.show();
}
function AS_Button_f84543b328a24821ac0b43419407ed30(eventobject) {
    out_RevealLtoR(frmStopsNearMe);
    frmHome.show();
}
function AS_FlexContainer_0d13db7f1f1c4799b504d417e30811c9(eventobject) {
    onClickOfGPSForCurrentLocation();
}
function AS_FlexContainer_1037ee56b7bf4bf38cd3d5be18c32d7f(eventobject) {
    onClickOfSearchBtnInfrmHome(false);
}
function AS_FlexContainer_18bb54338695449aa93270890ccf7806(eventobject) {
    onClickOfSearchBtnInfrmSearchRoutes(false);
}
function AS_FlexContainer_3c8658401c8a487d8d62b7be9c4cff0e(eventobject) {
    in_MoveInRtoL(frmFavourites);
    frmFavourites.show();
}
function AS_FlexContainer_c2a6b2af56f646f68ed2d590c11d2974(eventobject) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_FlexContainer_e67978d74a3541c1a592f5e6d25f41be(eventobject) {
    onClickOfStopsNearMe();
}
function AS_FlexContainer_eb7ef403a1b34d3bb7611e72e24dc7ef(eventobject) {
    onClickOfSearchRoutesInFrmHome();
}
function AS_FlexContainer_ee7b6f702bf64abb9cec231f248a1162(eventobject) {
    onClickOfGPSForCurrentLocation();
}
function AS_Form_07014125500f4c1684e46409cffd99f0(eventobject) {
    preShowMethodofFrmHome();
}
function AS_Form_bc37d9a8bd914e4d8c9b0c6a4a0a456e(eventobject) {
    initializeJSONs();
}
function AS_Segment_43a852ca866543ad89af6284d4cc3fe0(eventobject, sectionNumber, rowNumber) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}
function AS_Segment_4a27234fe3394d7ea04b0a1f76e4c7b2(eventobject, sectionNumber, rowNumber) {
    onRowClickOfSegBusTracking();
}
function AS_Segment_4ae33034cee04fe092daa42d6a16cea6(eventobject, sectionNumber, rowNumber) {
    in_MoveInRtoL(frmBusInfo);
    frmBusInfo.show();
}
function AS_Segment_a66395c8c3a0443c81df6113a4360437(eventobject, sectionNumber, rowNumber) {
    onRowClickOfSegment();
}