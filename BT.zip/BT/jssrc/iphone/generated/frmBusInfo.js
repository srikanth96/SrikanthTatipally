function addWidgetsfrmBusInfo() {
    frmBusInfo.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var imgHeaderBack = new kony.ui.Image2({
        "centerY": "50%",
        "height": "24dp",
        "id": "imgHeaderBack",
        "isVisible": true,
        "left": "5%",
        "skin": "slImage",
        "src": "back_btnn_white.png",
        "top": "12%",
        "width": "19dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblHeaderTitle = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblHeaderTitle",
        "isVisible": true,
        "left": "12%",
        "skin": "sknLblFFFFFFNews36",
        "text": "Bus  Info",
        "top": "12dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var btnBack = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopyslButtonGlossBlue010ff396f1e184b",
        "height": "50dp",
        "id": "btnBack",
        "isVisible": true,
        "left": 2,
        "onClick": AS_Button_b3d2d4ed84144957b320faf2f2bcaa6a,
        "right": "5%",
        "skin": "CopyslButtonGlossBlue010ff396f1e184b",
        "text": "Button",
        "top": "83%",
        "width": "50dp",
        "zIndex": 3
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    flxHeader.add(
    imgHeaderBack, lblHeaderTitle, btnBack);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "91%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "CopyslFbox0c662c5a242d84b",
        "top": "9%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var flxBusInfo = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "25%",
        "id": "flxBusInfo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxBusInfo.setDefaultUnit(kony.flex.DP);
    var lblBusNo = new kony.ui.Label({
        "height": "22%",
        "id": "lblBusNo",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel08a2c4ccc0ca740",
        "text": "10W/17W",
        "top": "10%",
        "width": "40%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var imgBus = new kony.ui.Image2({
        "height": "35dp",
        "id": "imgBus",
        "isVisible": true,
        "left": "46%",
        "skin": "slImage",
        "src": "bus_place.png",
        "top": "10%",
        "width": "35dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var imgTime = new kony.ui.Image2({
        "height": "35dp",
        "id": "imgTime",
        "isVisible": true,
        "left": "46%",
        "skin": "slImage",
        "src": "time_icon.png",
        "top": "43%",
        "width": "35dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblBusType = new kony.ui.Label({
        "height": "13%",
        "id": "lblBusType",
        "isVisible": true,
        "left": "5%",
        "skin": "CopyslLabel019c71b82a16246",
        "text": "Deluxe Service",
        "top": "68%",
        "width": "35%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var imgStatus = new kony.ui.Image2({
        "height": "41dp",
        "id": "imgStatus",
        "isVisible": true,
        "left": "5%",
        "skin": "slImage",
        "src": "bus_status.png",
        "top": "37%",
        "width": "35dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblBusLocation = new kony.ui.Label({
        "height": "20%",
        "id": "lblBusLocation",
        "isVisible": true,
        "left": "55%",
        "skin": "CopyslLabel0701b567f2fc549",
        "text": "Kondapur",
        "top": "8%",
        "width": "43%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDistace = new kony.ui.Label({
        "height": "10%",
        "id": "lblDistace",
        "isVisible": true,
        "left": "55%",
        "skin": "CopyslLabel047c22408f1a743",
        "text": "0.8Kms",
        "top": "27%",
        "width": "30%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTime = new kony.ui.Label({
        "height": "20%",
        "id": "lblTime",
        "isVisible": true,
        "left": "55%",
        "skin": "CopyslLabel043f19265cf6f41",
        "text": "5 Min. approx",
        "top": "45%",
        "width": "40%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblStatus = new kony.ui.Label({
        "height": "20%",
        "id": "lblStatus",
        "isVisible": true,
        "left": "15%",
        "skin": "CopyslLabel043f19265cf6f41",
        "text": "Half Filled",
        "top": "43%",
        "width": "31%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDeparture = new kony.ui.Label({
        "bottom": "0%",
        "centerX": "50%",
        "height": "22%",
        "id": "lblDeparture",
        "isVisible": true,
        "left": "80%",
        "skin": "CopyslLabel0b889ee049cec4b",
        "text": "Depart at Ammerpet and take 10H",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxBusInfo.add(
    lblBusNo, imgBus, imgTime, lblBusType, imgStatus, lblBusLocation, lblDistace, lblTime, lblStatus, lblDeparture);
    var flxLine = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1dp",
        "id": "flxLine",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "10dp",
        "skin": "sknFlxA0B1C2BG50op",
        "top": "0%",
        "width": "80%",
        "zIndex": 1
    }, {}, {});
    flxLine.setDefaultUnit(kony.flex.DP);
    flxLine.add();
    var lblBusStopsTitile = new kony.ui.Label({
        "id": "lblBusStopsTitile",
        "isVisible": true,
        "left": "5%",
        "skin": "CopysknLblFFFFFFNews0743fc422bdfb4e",
        "text": "Bus Stops",
        "top": "2%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var flxScrollBus = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "bounces": false,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "66%",
        "horizontalScrollIndicator": false,
        "id": "flxScrollBus",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "2.00%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {
        "bouncesZoom": false
    });
    flxScrollBus.setDefaultUnit(kony.flex.DP);
    flxScrollBus.add();
    flxBody.add(
    flxBusInfo, flxLine, lblBusStopsTitile, flxScrollBus);
    flxOuter.add(
    flxHeader, flxBody);
    frmBusInfo.add(
    flxOuter);
};

function frmBusInfoGlobals() {
    frmBusInfo = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmBusInfo,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "frmBusInfo",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "sknFrmStandardGradient",
        "statusBarHidden": false
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": false,
        "bouncesZoom": false,
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};