function initializesegTempFavRoutesList() {
    flxSegTempFavRoutes = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "60dp",
        "id": "flxSegTempFavRoutes",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxSegTempFavRoutes.setDefaultUnit(kony.flex.DP);
    var lblFrom = new kony.ui.Label({
        "centerY": "50%",
        "height": "90%",
        "id": "lblFrom",
        "isVisible": true,
        "left": "3%",
        "right": "7%",
        "skin": "sknLbl5E5050News93",
        "text": "FULL",
        "top": "10%",
        "width": "40%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTo = new kony.ui.Label({
        "centerY": "50%",
        "height": "90%",
        "id": "lblTo",
        "isVisible": true,
        "right": "3%",
        "skin": "sknLbl5E5050News93",
        "text": "FULL",
        "top": "10%",
        "width": "40%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblLine = new kony.ui.Label({
        "bottom": "0%",
        "height": "1dp",
        "id": "lblLine",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblD8D8D8BGop50",
        "text": ":",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var imgarrow = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "30dp",
        "id": "imgarrow",
        "isVisible": true,
        "right": "7%",
        "skin": "slImage",
        "src": "arrow_with_both_sides.png",
        "top": "83dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSegTempFavRoutes.add(
    lblFrom, lblTo, lblLine, imgarrow);
}