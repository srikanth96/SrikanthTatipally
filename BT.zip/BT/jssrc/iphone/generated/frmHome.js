function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var imgHeaderBusIcon = new kony.ui.Image2({
        "centerY": "50%",
        "height": "24dp",
        "id": "imgHeaderBusIcon",
        "isVisible": true,
        "left": "5%",
        "skin": "slImage",
        "src": "busheadericon.png",
        "top": "12%",
        "width": "19dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblHeaderTitle = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblHeaderTitle",
        "isVisible": true,
        "left": "12%",
        "skin": "sknLblFFFFFFNews36",
        "text": "B-Track",
        "top": "12dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var flxMapView = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "40dp",
        "id": "flxMapView",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "78%",
        "onClick": AS_FlexContainer_c2a6b2af56f646f68ed2d590c11d2974,
        "skin": "slFbox",
        "top": "20%",
        "width": "40dp"
    }, {}, {});
    flxMapView.setDefaultUnit(kony.flex.DP);
    var imgMapView = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "30dp",
        "id": "imgMapView",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "map_view.png",
        "top": "0dp",
        "width": "30dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxMapView.add(
    imgMapView);
    var imgHeaderMenuIcon = new kony.ui.Image2({
        "centerY": "50%",
        "height": "27dp",
        "id": "imgHeaderMenuIcon",
        "isVisible": true,
        "right": "5%",
        "skin": "slImage",
        "src": "action.png",
        "top": "12%",
        "width": "6dp"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxHeader.add(
    imgHeaderBusIcon, lblHeaderTitle, flxMapView, imgHeaderMenuIcon);
    var flxInputArea = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": false,
        "height": "22%",
        "id": "flxInputArea",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknFlx000000BGop20rad15",
        "top": "8%",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    flxInputArea.setDefaultUnit(kony.flex.DP);
    var lblFrom = new kony.ui.Label({
        "height": "13%",
        "id": "lblFrom",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblFFFFFFBook28",
        "text": "From",
        "top": "5%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var txtCurrentLocation = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "sknTbx000000BGop15RCFFFFFFNews100",
        "height": "24%",
        "id": "txtCurrentLocation",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "0%",
        "placeholder": "My Current Location",
        "secureTextEntry": false,
        "skin": "sknTbx000000BGop15RCFFFFFFNews100",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "20%",
        "width": "89%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "closeButtonRequired": true,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "placeholderSkin": "sknTbx000000BGop15RCFFFFFFBook100",
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var flxGPS = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40dp",
        "id": "flxGPS",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "90%",
        "onClick": AS_FlexContainer_ee7b6f702bf64abb9cec231f248a1162,
        "skin": "slFbox",
        "top": "20%",
        "width": "40dp"
    }, {}, {});
    flxGPS.setDefaultUnit(kony.flex.DP);
    var lblGPS = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "45%",
        "height": "25dp",
        "id": "lblGPS",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "gps.png",
        "top": "0dp",
        "width": "25dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxGPS.add(
    lblGPS);
    var lblTo = new kony.ui.Label({
        "height": "13%",
        "id": "lblTo",
        "isVisible": true,
        "left": "0%",
        "skin": "sknLblFFFFFFBook28",
        "text": "To",
        "top": "49%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var txtGoToLocation = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "focusSkin": "sknTbx000000BGop15RCFFFFFFNews100",
        "height": "24%",
        "id": "txtGoToLocation",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "0%",
        "placeholder": "Go To Location",
        "secureTextEntry": false,
        "skin": "sknTbx000000BGop15RCFFFFFFNews100",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "64%",
        "width": "89%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "closeButtonRequired": true,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "placeholderSkin": "sknTbx000000BGop15RCFFFFFFBook100",
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var flxSearchBuses = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "40dp",
        "id": "flxSearchBuses",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "90%",
        "onClick": AS_FlexContainer_1037ee56b7bf4bf38cd3d5be18c32d7f,
        "skin": "slFbox",
        "top": "64%",
        "width": "40dp"
    }, {}, {});
    flxSearchBuses.setDefaultUnit(kony.flex.DP);
    var imgSearchBuses = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "45%",
        "height": "25dp",
        "id": "imgSearchBuses",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "search.png",
        "top": "0dp",
        "width": "25dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSearchBuses.add(
    imgSearchBuses);
    flxInputArea.add(
    lblFrom, txtCurrentLocation, flxGPS, lblTo, txtGoToLocation, flxSearchBuses);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "61%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0c662c5a242d84b",
        "top": "30%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var segBusTracking = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "btnBusMap": "Button",
            "imgBusMap": "show_map_view.png",
            "lblBusLocation": "Current Location",
            "lblBusLocationValue": "Kondapur",
            "lblBusNo": "Bus No.",
            "lblBusNoValue": "10H",
            "lblBusType": "Type of",
            "lblBusTypeValue": "Metro",
            "lblColon1": ":",
            "lblColon2": ":",
            "lblColon3": ":",
            "lblColon4": ":",
            "lblColon5": ":",
            "lblColon6": ":",
            "lblDistance": "Distance",
            "lblDistanceValue": "2 Kms",
            "lblLine": ":",
            "lblStatus": "Status",
            "lblStatusValue": "FULL",
            "lblTime": "Estimated Time",
            "lblTimeValue": "8 Min"
        }, {
            "btnBusMap": "Button",
            "imgBusMap": "show_map_view.png",
            "lblBusLocation": "Current Location",
            "lblBusLocationValue": "Kondapur",
            "lblBusNo": "Bus No.",
            "lblBusNoValue": "10H",
            "lblBusType": "Type of",
            "lblBusTypeValue": "Deluxe Non - A/C",
            "lblColon1": ":",
            "lblColon2": ":",
            "lblColon3": ":",
            "lblColon4": ":",
            "lblColon5": ":",
            "lblColon6": ":",
            "lblDistance": "Distance",
            "lblDistanceValue": "2 Kms",
            "lblLine": ":",
            "lblStatus": "Status",
            "lblStatusValue": "FULL",
            "lblTime": "Estimated Time",
            "lblTimeValue": "8 Min"
        }, {
            "btnBusMap": "Button",
            "imgBusMap": "show_map_view.png",
            "lblBusLocation": "Current Location",
            "lblBusLocationValue": "Kondapur",
            "lblBusNo": "Bus No.",
            "lblBusNoValue": "10H",
            "lblBusType": "Type of",
            "lblBusTypeValue": "Ordinary",
            "lblColon1": ":",
            "lblColon2": ":",
            "lblColon3": ":",
            "lblColon4": ":",
            "lblColon5": ":",
            "lblColon6": ":",
            "lblDistance": "Distance",
            "lblDistanceValue": "2 Kms",
            "lblLine": ":",
            "lblStatus": "Status",
            "lblStatusValue": "EMPTY",
            "lblTime": "Estimated Time",
            "lblTimeValue": "8 Min"
        }, {
            "btnBusMap": "Button",
            "imgBusMap": "show_map_view.png",
            "lblBusLocation": "Current Location",
            "lblBusLocationValue": "Kondapur",
            "lblBusNo": "Bus No.",
            "lblBusNoValue": "10H",
            "lblBusType": "Type of",
            "lblBusTypeValue": "Deluxe A/C",
            "lblColon1": ":",
            "lblColon2": ":",
            "lblColon3": ":",
            "lblColon4": ":",
            "lblColon5": ":",
            "lblColon6": ":",
            "lblDistance": "Distance",
            "lblDistanceValue": "2 Kms",
            "lblLine": ":",
            "lblStatus": "Status",
            "lblStatusValue": "EMPTY",
            "lblTime": "Estimated Time",
            "lblTimeValue": "8 Min"
        }, {
            "btnBusMap": "Button",
            "imgBusMap": "show_map_view.png",
            "lblBusLocation": "Current Location",
            "lblBusLocationValue": "Kondapur",
            "lblBusNo": "Bus No.",
            "lblBusNoValue": "10H",
            "lblBusType": "Type of",
            "lblBusTypeValue": "Metro",
            "lblColon1": ":",
            "lblColon2": ":",
            "lblColon3": ":",
            "lblColon4": ":",
            "lblColon5": ":",
            "lblColon6": ":",
            "lblDistance": "Distance",
            "lblDistanceValue": "2 Kms",
            "lblLine": ":",
            "lblStatus": "Status",
            "lblStatusValue": "EMPTY",
            "lblTime": "Estimated Time",
            "lblTimeValue": "8 Min"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segBusTracking",
        "isVisible": true,
        "left": "0%",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_4a27234fe3394d7ea04b0a1f76e4c7b2,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "sknSegE4E8ECBGFocus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxTempBusTrack,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": false,
        "showScrollbars": false,
        "top": "0%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "btnBusMap": "btnBusMap",
            "flxTempBusTrack": "flxTempBusTrack",
            "imgBusMap": "imgBusMap",
            "lblBusLocation": "lblBusLocation",
            "lblBusLocationValue": "lblBusLocationValue",
            "lblBusNo": "lblBusNo",
            "lblBusNoValue": "lblBusNoValue",
            "lblBusType": "lblBusType",
            "lblBusTypeValue": "lblBusTypeValue",
            "lblColon1": "lblColon1",
            "lblColon2": "lblColon2",
            "lblColon3": "lblColon3",
            "lblColon4": "lblColon4",
            "lblColon5": "lblColon5",
            "lblColon6": "lblColon6",
            "lblDistance": "lblDistance",
            "lblDistanceValue": "lblDistanceValue",
            "lblLine": "lblLine",
            "lblStatus": "lblStatus",
            "lblStatusValue": "lblStatusValue",
            "lblTime": "lblTime",
            "lblTimeValue": "lblTimeValue"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": false,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_NONE,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    flxBody.add(
    segBusTracking);
    var flxBottom = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0%",
        "clipBounds": true,
        "height": "9%",
        "id": "flxBottom",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0%",
        "skin": "slFbox",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBottom.setDefaultUnit(kony.flex.DP);
    var flxSearchRoute = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "99%",
        "id": "flxSearchRoute",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_eb7ef403a1b34d3bb7611e72e24dc7ef,
        "skin": "slFbox",
        "top": "0%",
        "width": "20%"
    }, {}, {});
    flxSearchRoute.setDefaultUnit(kony.flex.DP);
    var imgSearchRoute = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "40dp",
        "id": "imgSearchRoute",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "directions.png",
        "top": "0dp",
        "width": "40dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSearchRoute.add(
    imgSearchRoute);
    var flxStopsNearMe = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "99%",
        "id": "flxStopsNearMe",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_e67978d74a3541c1a592f5e6d25f41be,
        "skin": "slFbox",
        "top": "0%",
        "width": "20%"
    }, {}, {});
    flxStopsNearMe.setDefaultUnit(kony.flex.DP);
    var imgStopsNearMe = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "40dp",
        "id": "imgStopsNearMe",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "bus_stop.png",
        "top": "0dp",
        "width": "40dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxStopsNearMe.add(
    imgStopsNearMe);
    var flxFavourites = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "99%",
        "id": "flxFavourites",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "onClick": AS_FlexContainer_3c8658401c8a487d8d62b7be9c4cff0e,
        "skin": "slFbox",
        "top": "0%",
        "width": "20%"
    }, {}, {});
    flxFavourites.setDefaultUnit(kony.flex.DP);
    var imgFavourites = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "40dp",
        "id": "imgFavourites",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "fav.png",
        "top": "0dp",
        "width": "40dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxFavourites.add(
    imgFavourites);
    var flxUserInput = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "99%",
        "id": "flxUserInput",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "20%"
    }, {}, {});
    flxUserInput.setDefaultUnit(kony.flex.DP);
    var imgUserInput = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "40dp",
        "id": "imgUserInput",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "user_input.png",
        "top": "0dp",
        "width": "40dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxUserInput.add(
    imgUserInput);
    var flxSOS = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "99%",
        "id": "flxSOS",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "slFbox",
        "top": "0%",
        "width": "20%"
    }, {}, {});
    flxSOS.setDefaultUnit(kony.flex.DP);
    var imgSOS = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "40dp",
        "id": "imgSOS",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "sos.png",
        "top": "0dp",
        "width": "40dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxSOS.add(
    imgSOS);
    flxBottom.add(
    flxSearchRoute, flxStopsNearMe, flxFavourites, flxUserInput, flxSOS);
    flxOuter.add(
    flxHeader, flxInputArea, flxBody, flxBottom);
    frmHome.add(
    flxOuter);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "init": AS_Form_bc37d9a8bd914e4d8c9b0c6a4a0a456e,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_07014125500f4c1684e46409cffd99f0,
        "skin": "sknFrmStandardGradient",
        "statusBarHidden": false
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": false,
        "bouncesZoom": false,
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};