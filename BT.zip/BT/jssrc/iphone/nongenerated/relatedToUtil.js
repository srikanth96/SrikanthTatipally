function isNullable(value) {
    if (value === undefined || value === null || value === "" || value.length === 0) {
        return true;
    }
    return false;
}