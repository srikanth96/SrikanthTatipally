function resetFrmStopsNearMe() {
    frmStopsNearMe.btnViewOnMap.setEnabled(false);
    frmStopsNearMe.btnViewOnMap.opacity = "0.5";
    frmStopsNearMe.segBusStops.isVisible = false;
}

function onClickOfRefreshBtn() {
    data = searchBusStopsNearMe();
    if (kony.application.getCurrentForm() === frmStopsNearMe) {
        frmStopsNearMe.segBusStops.removeAll();
        frmStopsNearMe.segBusStops.setData(data);
        EnableMapBtnAndSeg();
    } else {
        return data[0].lblBusStop;
    }
}

function searchBusStopsNearMe() {
    var data = [{
        "lblBusStop": "Wave Rock",
        "lblLine": ":"
    }, {
        "lblBusStop": "DLF",
        "lblLine": ":"
    }];
    return data;
}

function EnableMapBtnAndSeg() {
    frmStopsNearMe.btnViewOnMap.setEnabled(true);
    frmStopsNearMe.btnViewOnMap.opacity = "1";
    frmStopsNearMe.segBusStops.isVisible = true;
}