var gfavBusNumberList = [];
var gAllBusStopsList = [];
var gAllBusNumberList = [];
var gBusRouteList = [];

function initializeJSONs() {
    initialize_allBusNos();
    initialize_allBusStops();
    initializes_setBusRoutes();
}

function initialize_allBusNos() {
    var buslist = {
        "bus_id": "1",
        "bus_service_no": "250S",
        "bus_type": "Ordinary",
        "capcity": "50",
        "present_stop": "2",
        "towards": "8"
    }
    gAllBusNumberList.push(buslist);
    buslist = {
        "bus_id": "2",
        "bus_service_no": "250S",
        "bus_type": "Metro",
        "capcity": "50",
        "present_stop": "7",
        "towards": "1"
    }
    gAllBusNumberList.push(buslist);
    buslist = {
        "bus_id": "3",
        "bus_service_no": "250S",
        "bus_type": "Ordinary",
        "capcity": "50",
        "present_stop": "4",
        "towards": "8"
    }
    gAllBusNumberList.push(buslist);
    buslist = {
        "bus_id": "4",
        "bus_service_no": "250S",
        "bus_type": "Ordinary",
        "capcity": "50",
        "present_stop": "6",
        "towards": "1"
    }
    gAllBusNumberList.push(buslist);
}

function initialize_allBusStops() {
    var busStops = {
        "bus_stop_id": "1",
        "bus_stop_long": "Shakthi Sai Nagar (Mallapur)",
        "bus_stop_short": "SSN",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "2",
        "bus_stop_long": "Mallapur",
        "bus_stop_short": "MLPR",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "3",
        "bus_stop_long": "Nacharam",
        "bus_stop_short": "NCHM",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "4",
        "bus_stop_long": "HMT Nagar",
        "bus_stop_short": "HMT",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "5",
        "bus_stop_long": "Habsiguda",
        "bus_stop_short": "HBG",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "6",
        "bus_stop_long": "Tarnka",
        "bus_stop_short": "TRK",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "7",
        "bus_stop_long": "Mettuguda",
        "bus_stop_short": "MTG",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
    busStops = {
        "bus_stop_id": "8",
        "bus_stop_long": "Secunderabad Bus Stops",
        "bus_stop_short": "SECBAD",
        "geo_location": {
            "lat": "0",
            "long": "0"
        }
    };
    gAllBusStopsList.push(busStops);
}

function initializes_setBusRoutes() {
    var busRoute = {
        "s_no": "1",
        "bus_service_no": "250S",
        "bus_stop_id": "1",
        "order": "1"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "2",
        "bus_service_no": "250S",
        "bus_stop_id": "2",
        "order": "2"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "3",
        "bus_service_no": "250S",
        "bus_stop_id": "3",
        "order": "3"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "4",
        "bus_service_no": "250S",
        "bus_stop_id": "4",
        "order": "4"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "5",
        "bus_service_no": "250S",
        "bus_stop_id": "5",
        "order": "5"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "6",
        "bus_service_no": "250S",
        "bus_stop_id": "6",
        "order": "6"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "7",
        "bus_service_no": "250S",
        "bus_stop_id": "7",
        "order": "7"
    }
    gBusRouteList.push(busRoute);
    busRoute = {
        "s_no": "8",
        "bus_service_no": "250S",
        "bus_stop_id": "8",
        "order": "8"
    }
    gBusRouteList.push(busRoute);
}