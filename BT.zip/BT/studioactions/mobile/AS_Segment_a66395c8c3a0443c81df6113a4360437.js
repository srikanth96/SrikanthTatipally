function AS_Segment_a66395c8c3a0443c81df6113a4360437(eventobject, sectionNumber, rowNumber) {
    onRowClickOfSegment();
}