function AS_Segment_4ae33034cee04fe092daa42d6a16cea6(eventobject, sectionNumber, rowNumber) {
    in_MoveInRtoL(frmBusInfo);
    frmBusInfo.show();
}