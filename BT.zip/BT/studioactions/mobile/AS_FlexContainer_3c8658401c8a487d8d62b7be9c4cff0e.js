function AS_FlexContainer_3c8658401c8a487d8d62b7be9c4cff0e(eventobject) {
    in_MoveInRtoL(frmFavourites);
    frmFavourites.show();
}