function AS_FlexContainer_e67978d74a3541c1a592f5e6d25f41be(eventobject) {
    onClickOfStopsNearMe();
}