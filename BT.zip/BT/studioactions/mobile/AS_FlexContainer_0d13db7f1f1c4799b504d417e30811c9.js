function AS_FlexContainer_0d13db7f1f1c4799b504d417e30811c9(eventobject) {
    onClickOfGPSForCurrentLocation();
}