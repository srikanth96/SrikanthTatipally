function AS_Segment_43a852ca866543ad89af6284d4cc3fe0(eventobject, sectionNumber, rowNumber) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}