function AS_Form_bc37d9a8bd914e4d8c9b0c6a4a0a456e(eventobject) {
    initializeJSONs();
}