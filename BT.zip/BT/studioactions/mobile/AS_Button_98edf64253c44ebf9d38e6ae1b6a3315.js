function AS_Button_98edf64253c44ebf9d38e6ae1b6a3315(eventobject) {
    in_MoveInRtoL(frmMapView);
    frmMapView.show();
}