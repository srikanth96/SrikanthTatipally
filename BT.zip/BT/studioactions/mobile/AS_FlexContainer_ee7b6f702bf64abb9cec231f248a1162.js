function AS_FlexContainer_ee7b6f702bf64abb9cec231f248a1162(eventobject) {
    onClickOfGPSForCurrentLocation();
}