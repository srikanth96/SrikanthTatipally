function AS_Segment_4a27234fe3394d7ea04b0a1f76e4c7b2(eventobject, sectionNumber, rowNumber) {
    onRowClickOfSegBusTracking();
}