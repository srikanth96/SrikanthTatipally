function AS_Button_8eb3b28252f846d9b01832486ed569bf(eventobject) {
    var prevForm = kony.application.getPreviousForm();
    out_RevealLtoR(frmMapView);
    prevForm.show();
}