function AS_Button_b3d2d4ed84144957b320faf2f2bcaa6a(eventobject) {
    var prevForm = kony.application.getPreviousForm();
    out_RevealLtoR(frmBusInfo);
    prevForm.show();
}