function AS_Button_9057ff3cfeed471ead3e9cefa66b363d(eventobject) {
    onClickOfRefreshBtn();
}